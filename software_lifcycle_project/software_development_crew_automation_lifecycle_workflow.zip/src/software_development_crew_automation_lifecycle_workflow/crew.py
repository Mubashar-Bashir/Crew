from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task


@CrewBase
class SoftwareDevelopmentCrewAutomationLifecycleWorkflowCrew():
    """SoftwareDevelopmentCrewAutomationLifecycleWorkflow crew"""

    @agent
    def project_manager(self) -> Agent:
        return Agent(
            config=self.agents_config['project_manager'],
            tools=[],
        )

    @agent
    def business_analyst(self) -> Agent:
        return Agent(
            config=self.agents_config['business_analyst'],
            tools=[],
        )

    @agent
    def software_architect(self) -> Agent:
        return Agent(
            config=self.agents_config['software_architect'],
            tools=[],
        )

    @agent
    def developer(self) -> Agent:
        return Agent(
            config=self.agents_config['developer'],
            tools=[],
        )

    @agent
    def qa_engineer(self) -> Agent:
        return Agent(
            config=self.agents_config['qa_engineer'],
            tools=[],
        )

    @agent
    def technical_writer(self) -> Agent:
        return Agent(
            config=self.agents_config['technical_writer'],
            tools=[],
        )


    @task
    def define_sdlc_roadmap_task(self) -> Task:
        return Task(
            config=self.tasks_config['define_sdlc_roadmap_task'],
            tools=[],
        )

    @task
    def gather_requirements_task(self) -> Task:
        return Task(
            config=self.tasks_config['gather_requirements_task'],
            tools=[],
        )

    @task
    def architectural_design_task(self) -> Task:
        return Task(
            config=self.tasks_config['architectural_design_task'],
            tools=[],
        )

    @task
    def development_implementation_task(self) -> Task:
        return Task(
            config=self.tasks_config['development_implementation_task'],
            tools=[],
        )

    @task
    def qa_testing_task(self) -> Task:
        return Task(
            config=self.tasks_config['qa_testing_task'],
            tools=[],
        )

    @task
    def documentation_deployment_task(self) -> Task:
        return Task(
            config=self.tasks_config['documentation_deployment_task'],
            tools=[],
        )


    @crew
    def crew(self) -> Crew:
        """Creates the SoftwareDevelopmentCrewAutomationLifecycleWorkflow crew"""
        return Crew(
            agents=self.agents, # Automatically created by the @agent decorator
            tasks=self.tasks, # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
